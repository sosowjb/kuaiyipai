﻿using Abp.Application.Services.Dto;

namespace Kuaiyipai.Auction.Address.Dto
{
    public class GetAddressesInputDto : PagedAndSortedResultRequestDto
    {
        
    }
}