﻿using Abp.Application.Services.Dto;

namespace Kuaiyipai.Auction.Pillar.Dto
{
    public class GetPillarsInputDto : PagedAndSortedResultRequestDto
    {

    }
}