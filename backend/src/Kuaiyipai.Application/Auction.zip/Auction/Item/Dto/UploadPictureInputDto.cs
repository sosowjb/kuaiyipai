﻿namespace Kuaiyipai.Auction.Item.Dto
{
    public class UploadPictureInputDto
    {
        public string Base64 { get; set; }
    }
}