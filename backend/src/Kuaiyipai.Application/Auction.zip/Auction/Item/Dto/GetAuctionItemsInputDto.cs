﻿using Abp.Application.Services.Dto;
using System;
using System.Collections.Generic;
using System.Text;

namespace Kuaiyipai.Auction.Item.Dto
{
     public class GetAuctionItemsInputDto : PagedAndSortedResultRequestDto
    {
    }
}
