﻿using Abp.Application.Services.Dto;

namespace Kuaiyipai.Auction.Item.Dto
{
    public class GetMyTerminatedItemsInputDto : PagedAndSortedResultRequestDto
    {

    }
}