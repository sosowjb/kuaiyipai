﻿namespace Kuaiyipai.Auction.Balance.Dto
{
    public class WithdrawInputDto
    {
        public double Amount { get; set; }
    }
}