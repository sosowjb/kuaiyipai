﻿using Abp.Application.Services.Dto;

namespace Kuaiyipai.Auction.Balance.Dto
{
    public class GetMyBalanceRecordsInputDto : PagedAndSortedResultRequestDto
    {
        
    }
}