﻿namespace Kuaiyipai.Auction.Balance.Dto
{
    public class ChargeInputDto
    {
        public double Amount { get; set; }

        public string LoginCode { get; set; }
    }
}