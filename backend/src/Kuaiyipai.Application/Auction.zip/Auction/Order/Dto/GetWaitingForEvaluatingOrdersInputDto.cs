﻿using Abp.Application.Services.Dto;

namespace Kuaiyipai.Auction.Order.Dto
{
    public class GetWaitingForEvaluatingOrdersInputDto : PagedAndSortedResultRequestDto
    {
        
    }
}